# FaceID > 2022-08-01 12:56pm
https://universe.roboflow.com/object-detection/faceid-nswkq

Provided by Roboflow
License: CC BY 4.0

